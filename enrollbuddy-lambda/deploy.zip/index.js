const axios = require("axios");
const transporter = require('./mailer');

exports.handler = async (event) => {
  const api = `https://5346-183-82-1-214.ngrok-free.app`;
  const intentName = event.sessionState.intent.name;
  if (intentName === "CourseDetails") {
    const slots = event.sessionState.intent.slots;
    const searchTypeValue = slots.searchTypeValue.value.originalValue;
    const specificField = slots.specificType.value.originalValue;
    let courseId, courseName;
    if (slots.searchType.value.originalValue === "courseId") {
      courseId = searchTypeValue;
    } else if (slots.searchType.value.originalValue === "courseName") {
      courseName = searchTypeValue;
    }
    const courseDetailsData = await axios(`${api}/course-details`, {
      params: {
        courseId,
        courseName,
        field: specificField,
      },
    });
    const response = {
      sessionState: {
        dialogAction: {
          type: "Close",
        },
        intent: {
          name: intentName,
          state: "Fulfilled",
        },
      },
      messages: [
        courseDetailsData.data,
        {
          contentType: "ImageResponseCard",
          imageResponseCard: {
            title: "Is there anything else I can assist you with?",
            buttons: [
              {
                text: "Yes",
                value: "Yes, I want further assistance.",
              },
              {
                text: "No",
                value: "Goodbye",
              },
            ],
          },
        },
      ],
    };
    return response;
  } else if(intentName === 'EnrollCourse') {
    const slots = event.sessionState.intent.slots;
    const courseId = slots.courseId.value.originalValue;
    const courseData = await axios(`${api}/course-details`, {
      params: {
        courseId,
      },
    });
    const body = `Hello
                <p>Please!! you can reset your password using the following link:</p>
                <p><a href="#"> Reset Password</a></p>

                Your Course Details:
                ${courseData.data.imageResponseCard}
                
                <p>You can enroll in this course directly from our website by clicking the link below:</p>
                <p><a href="#">Enroll Now</a></p>

                <p>Best regards,</p>
                <p>Enroll Buddy</p>
                `;
    const mailOptions = {
        from: process.env.GMAIL_USER,
        to: slots.toEmail.value.originalValue,
        subject: "Course Details, Password Reset, and Easy Enrollment Await You!",
        text: body
    }
  }
};
